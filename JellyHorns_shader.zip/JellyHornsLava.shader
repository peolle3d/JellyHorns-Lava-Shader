Shader "Custom/JellyHorns Lava V4 DepthFix"
{
 Properties
 {
  _ShellColor ("Jelly Color RGBA", Color) = (0.95,0.42,0.25,0.38)
  _BlobColor ("Blob Color", Color) = (1,0.65,0.12,1)
  _RimColor ("Rim Color", Color) = (1,0.78,0.54,1)
  _Gloss ("Gloss", Range(0,3)) = 0.75
  _GlossPower ("Gloss Sharpness", Range(8,256)) = 95
  _RimStrength ("Rim Strength", Range(0,3)) = 0.45
  _RimPower ("Rim Sharpness", Range(0.5,8)) = 2.8
  _BlobOpacity ("Blob Visibility", Range(0,1)) = 0.85
  _BlobGlow ("Blob Brightness", Range(0,3)) = 0.25
  _Speed ("Movement Speed", Range(0,3)) = 0.32
  _BlobSize ("Blob Radius", Range(0.1,1.5)) = 0.48
  _Merge ("Merging Softness", Range(0.01,0.7)) = 0.28
  _Density ("Blobs Per Object Unit", Range(2,80)) = 18
  _SoftEdge ("Blob Edge Softness", Range(0.01,0.4)) = 0.14
  _Depth ("Visible Interior Depth", Range(0.001,0.15)) = 0.025
  _RaySteps ("Interior Samples", Range(2,12)) = 6
  _PhaseSplit ("Left Right Animation Difference", Range(0,8)) = 2.4
  _SplitX ("Left Right Split (Local X)", Float) = 0

  [Toggle] _HornOutlineOn ("Enable Horn Outline", Float) = 0
  _HornOutlineColor ("Horn Outline Color", Color) = (0.34,0.09,0.18,1)
  _HornOutlineWidth ("Horn Outline Width (Object Units)", Range(0,0.02)) = 0.0015

  [Toggle] _BlobOutlineOn ("Enable Blob Outline", Float) = 1
  _BlobOutlineColor ("Blob Outline Color", Color) = (0.7,0.18,0.13,1)
  _BlobOutlineWidth ("Blob Outline Width (Field Units)", Range(0.001,0.35)) = 0.055
  _BlobOutlineOpacity ("Blob Outline Opacity", Range(0,1)) = 0.8

  [Toggle] _BlobHighlightOn ("Enable Blob Highlight", Float) = 1
  [HDR] _BlobHighlightColor ("Blob Highlight Color", Color) = (1,0.92,0.75,1)
  _BlobHighlightIntensity ("Blob Highlight Intensity", Range(0,4)) = 0.8
  _BlobHighlightSize ("Blob Highlight Size", Range(0.01,1)) = 0.25
  _BlobHighlightSharpness ("Blob Highlight Sharpness", Range(1,12)) = 5
  _BlobHighlightPosition ("Blob Highlight Position XYZ", Vector) = (-0.35,0.75,0.5,0)
 }
 SubShader
 {
  Tags {"Queue"="Transparent" "RenderType"="Transparent" "IgnoreProjector"="True"}
  // Front-facing horn depth is established first, preventing outline bleed-through.
  // This intentionally makes the shell use front-surface transparency only.
  Pass
  {
   Name "HornDepth"
   Cull Back
   ZWrite On
   ZTest LEqual
   ColorMask 0
   CGPROGRAM
   #pragma target 3.0
   #pragma vertex vertDepth
   #pragma fragment fragDepth
   #include "UnityCG.cginc"
   struct appDepth {float4 vertex:POSITION;};
   struct outDepth {float4 pos:SV_POSITION;};
   outDepth vertDepth(appDepth v) {outDepth o; o.pos=UnityObjectToClipPos(v.vertex);return o;}
   fixed4 fragDepth(outDepth i):SV_Target {return fixed4(0,0,0,0);}
   ENDCG
  }
  // Backface expansion is masked by the front-facing depth prepass.
  Pass
  {
   Name "HornOutline"
   Cull Front
   ZWrite Off
   ZTest LEqual
   Blend SrcAlpha OneMinusSrcAlpha
   CGPROGRAM
   #pragma target 3.0
   #pragma vertex vertOutline
   #pragma fragment fragOutline
   #include "UnityCG.cginc"
   float _HornOutlineOn, _HornOutlineWidth;
   float4 _HornOutlineColor;
   struct ov {float4 vertex:POSITION;float3 normal:NORMAL;};
   struct of {float4 pos:SV_POSITION;};
   of vertOutline(ov v)
   {
    of o;
    float3 p=v.vertex.xyz+normalize(v.normal)*(_HornOutlineWidth*step(0.5,_HornOutlineOn));
    o.pos=UnityObjectToClipPos(float4(p,1));
    return o;
   }
   fixed4 fragOutline(of i):SV_Target
   {
    clip(_HornOutlineOn-0.5);
    return _HornOutlineColor;
   }
   ENDCG
  }
  Pass
  {
   Name "JellyLava"
   ZTest LEqual
   Tags {"LightMode"="ForwardBase"}
   Blend SrcAlpha OneMinusSrcAlpha
   ZWrite Off
   Cull Back
   CGPROGRAM
   #pragma target 3.0
   #pragma vertex vert
   #pragma fragment frag
   #include "UnityCG.cginc"
   float4 _ShellColor,_BlobColor,_RimColor;
   float _Gloss,_GlossPower,_RimStrength,_RimPower,_BlobOpacity,_BlobGlow;
   float _Speed,_BlobSize,_Merge,_Density,_SoftEdge,_Depth,_RaySteps,_PhaseSplit,_SplitX;
   float _BlobOutlineOn,_BlobOutlineWidth,_BlobOutlineOpacity;
   float4 _BlobOutlineColor;
   float _BlobHighlightOn,_BlobHighlightIntensity,_BlobHighlightSize,_BlobHighlightSharpness;
   float4 _BlobHighlightColor,_BlobHighlightPosition;
   struct appdata {float4 vertex:POSITION;float3 normal:NORMAL;};
   struct v2f {float4 pos:SV_POSITION;float3 objectPos:TEXCOORD0;float3 worldPos:TEXCOORD1;float3 normalWS:TEXCOORD2;};
   v2f vert(appdata v)
   {
    v2f o;
    o.pos=UnityObjectToClipPos(v.vertex);
    o.objectPos=v.vertex.xyz;
    o.worldPos=mul(unity_ObjectToWorld,v.vertex).xyz;
    o.normalWS=UnityObjectToWorldNormal(v.normal);
    return o;
   }
   float smoothMin(float a,float b,float k)
   {
    float h=saturate(0.5+0.5*(b-a)/max(k,0.001));
    return lerp(b,a,h)-k*h*(1-h);
   }
   float hash31(float3 p)
   {
    p=frac(p*0.1031);
    p+=dot(p,p.yzx+33.33);
    return frac((p.x+p.y)*p.z);
   }
   float cellBlobs(float3 p,float t)
   {
    float3 cell=floor(p);
    float d=10.0;
    [unroll] for(int x=-1;x<=1;x++)
    [unroll] for(int y=-1;y<=1;y++)
    [unroll] for(int z=-1;z<=1;z++)
    {
      float3 id=cell+float3(x,y,z);
      float seed=hash31(id);
      float3 center=id+0.5;
      center+=float3(0.20*sin(t*0.65+seed*6.28),
                     0.31*sin(t*0.45+seed*8.0),
                     0.20*cos(t*0.55+seed*7.2));
      float3 delta=(p-center)*float3(1.0,0.84,1.0);
      float radius=_BlobSize*(0.65+0.35*hash31(id+7.7));
      float sd=length(delta)-radius;
      d=smoothMin(d,sd,_Merge);
    }
    return d;
   }
   fixed4 frag(v2f i):SV_Target
   {
    float3 n=normalize(i.normalWS);
    float3 view=normalize(_WorldSpaceCameraPos.xyz-i.worldPos);
    float fres=pow(1-saturate(dot(n,view)),_RimPower);
    float3 lightDir=normalize(float3(0.3,0.8,0.5));
    float spec=pow(saturate(dot(n,normalize(view+lightDir))),_GlossPower)*_Gloss;
    float phase=(i.objectPos.x<_SplitX)?0:_PhaseSplit;
    float t=_Time.y*_Speed+phase;
    float3 p=i.objectPos*_Density;
    float3 inward=normalize(mul((float3x3)unity_WorldToObject,-view));
    float accum=0;
    float border=0;
    float bestD=10;
    float3 bestQ=p;
    [loop] for(int j=0;j<12;j++)
    {
      if(j>=(int)_RaySteps) break;
      float f=(j+0.5)/max(_RaySteps,1.0);
      float3 q=p+inward*(_Depth*_Density)*f;
      float d=cellBlobs(q,t);
      float m=1-smoothstep(-_SoftEdge,_SoftEdge,d);
      accum=max(accum,m);
      if(d<bestD) {bestD=d;bestQ=q;}
    }
    // Outline is evaluated ONCE from the nearest (minimum) SDF sample.
    // Evaluating a ring separately at every ray step produced nested rings.
    // Width now controls a single band inside the visible blob boundary.
    float w=max(_BlobOutlineWidth,0.001);
    float feather=min(0.012,max(0.001,w*0.2));
    border=smoothstep(-w-feather,-w,bestD)
          *(1.0-smoothstep(-feather,feather,bestD));
    float3 rgb=lerp(_ShellColor.rgb,_BlobColor.rgb*(1+_BlobGlow),accum*_BlobOpacity);
    float ringAlpha=border*_BlobOutlineOpacity*_BlobOutlineColor.a*step(0.5,_BlobOutlineOn)*accum;
    rgb=lerp(rgb,_BlobOutlineColor.rgb,ringAlpha);

    // Highlight follows the moving SDF field; gradient is evaluated only when enabled.
    if(_BlobHighlightOn>0.5 && accum>0.05)
    {
      const float eps=0.018;
      float3 grad=float3(
       cellBlobs(bestQ+float3(eps,0,0),t)-cellBlobs(bestQ-float3(eps,0,0),t),
       cellBlobs(bestQ+float3(0,eps,0),t)-cellBlobs(bestQ-float3(0,eps,0),t),
       cellBlobs(bestQ+float3(0,0,eps),t)-cellBlobs(bestQ-float3(0,0,eps),t));
      float3 blobN=normalize(grad+float3(0.0001,0.0001,0.0001));
      float3 hlDir=normalize(_BlobHighlightPosition.xyz+float3(0.0001,0.0001,0.0001));
      float align=saturate(dot(blobN,hlDir));
      float exponent=lerp(2.0,64.0,_BlobHighlightSharpness/12.0);
      exponent*=lerp(2.5,0.35,_BlobHighlightSize);
      float highlight=pow(align,max(1.0,exponent))*accum;
      // Avoid lighting an entire merged blob; favor its visible boundary.
      highlight*=1-smoothstep(-0.55,-0.03,bestD);
      rgb+=_BlobHighlightColor.rgb*highlight*_BlobHighlightIntensity*_BlobHighlightColor.a;
    }
    rgb+=_RimColor.rgb*fres*_RimStrength+spec.xxx;
    float a=saturate(_ShellColor.a+accum*_BlobOpacity*(1-_ShellColor.a)*0.8+fres*0.12);
    return fixed4(rgb,a);
   }
   ENDCG
  }
 }
 Fallback Off
}
